from setuptools import setup

setup(
    name = 'firstfunction',
    version ='1.0',
    description = 'Compare two unique letter or phrase in a set list',
    author = 'Sebastian',
    e_mail = 'bassepersson@hotmail.com',
    py_modules = ['firstfunction'],
)